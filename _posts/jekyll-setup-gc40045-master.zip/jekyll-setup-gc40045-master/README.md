# jekyll-simple

## simple
https://maynard-schools.github.io/jekyll-setup-gc40045/

## Story behind this theme

This is a project im making for my class
