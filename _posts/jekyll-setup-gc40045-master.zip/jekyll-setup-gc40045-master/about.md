---
layout: page
title: About
permalink: /about/
---

This is a website i made for my highschool class.
